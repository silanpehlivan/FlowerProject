# Çiçek Sınıflandırma — Proje Özeti ve Değişiklik Günlüğü

Bu repoda başlangıçta klasik renk + doku özniteliklerinden faydalanan bir çiçek sınıflandırma projesi vardı. Proje daha sonra Transfer Learning (MobileNetV2) tabanlı bir pipeline ve SVM sınıflandırıcısı ile güçlendirildi; ayrıca uygulama (Flask) tarafında güvenlik/kararlılık ve kullanıcı deneyimi iyileştirmeleri yapıldı.

Bu README, projenin kısa özeti, yapılan önemli değişiklikler, korunmuş dosyalar ve arşivlenen (taşınan) dosyaların listesini içerir.

**Kısa Öz:**
 # Çiçek Sınıflandırma — Proje Özeti ve Değişiklik Günlüğü

Bu repoda başlangıçta klasik renk + doku özniteliklerinden faydalanan bir çiçek sınıflandırma projesi vardı. Proje daha sonra Transfer Learning (MobileNetV2) tabanlı bir pipeline ve SVM sınıflandırıcısı ile güçlendirildi; ayrıca uygulama (Flask) tarafında kararlılık ve kullanıcı deneyimi iyileştirmeleri yapıldı.

Bu README aşağıdakileri içerir:
- Projenin kısa özeti
- Yapılan önemli değişikliklerin özeti
- Projede korunmuş dosyalar (uygulamanın düzgün çalışması için)
- `archive/` altına taşınan dosyaların listesi

## Kısa Öz
- Veri seti: `flower_photos/` (TensorFlow Flowers, 5 sınıf)
- Ana model: MobileNetV2 bottleneck özellikleri → SVM (negatif örneklerle iyileştirildi)
- Web arayüzü: Flask uygulaması `app.py`

## Yapılan Önemli Değişiklikler

- Transfer Learning (MobileNetV2) ile 1280 boyutlu bottleneck özellikleri çıkarma eklendi (`feature_extraction.py`, `extract_tl_features`).
- Transfer Learning özellikleri üzerinde SVM eğitildi ve **negatif (çiçek olmayan)** örnekler eklenerek `tl_improved_svm_model.pkl` ve `tl_improved_scaler.pkl` oluşturuldu. Bu sayede çiçek olmayan görseller reddedilebiliyor.
- `app.py` tarafında:
  - Ana model anahtarını merkezi `MAIN_MODEL_KEY` ile yöneten düzeltme yapıldı.
  - TL tabanlı güven (confidence) kontrolleri ve `skip_other_models` flag'i eklendi.
  - Flask reloader/dev-mode kaynaklı kararsızlıklar için sunucu `debug=False, use_reloader=False` ile çalışacak şekilde yapılandırıldı.
- UI güncellemeleri: `templates/index.html` ve `static/css/custom.css` içinde drag-and-drop, önizleme, spinner ve Türkçe etiketlemeler eklendi.

## Korunan Dosyalar (uygulamanın çalışması için)

Bu dosyalar uygulamanın çalışması için korunmuştur:
- `app.py`
- `feature_extraction.py`
- `templates/` ve `static/`
- `static/uploads/`
- Aktif/korunan modeller ve scalerler:
  - `tl_improved_svm_model.pkl`
  - `tl_improved_scaler.pkl`
  - `svm_(rbf_kernel)_model.pkl`
  - `knn_(k=5)_model.pkl`
  - `naive_bayes_model.pkl`
  - `scaler.pkl` (fallback)

## Arşivlenen (archive/) — taşınan dosyalar

Taşıma işlemi ile proje kökünden `archive/` altına aktarılan dosyalar (tam liste):

archive/models/
- `best_svm_model.pkl`
- `best_svm_random_tuned.pkl`
- `best_svm_classweight.pkl`
- `scaler_classweight.pkl`
- `temel_svm_rbf_kernel_model.pkl`
- `tl_svm_model.pkl`
- `tl_scaler.pkl`
- `tl_bottleneck_features.npz`
- `features_combined.pkl`
- `features_color_only.pkl`

archive/scripts/
- `train_improved_tl_model.py`
- `transfer_mobilenet_svm.py`
- `svm_random_tune.py`
- `svm_optimization.py`
- `svm_classweight_trial.py`
- `model_training.py`
- `read_features.py`
- `quick_boost.py`
- `inspect_models.py`
- `compute_model_stats.py`
- `analyze_misclass.py`
- `predict_single_image.py`

archive/images/
- Çok sayıda kök dizindeki ve `static/uploads/` altındaki `.png` çıktı/grafik/ekran görüntüsü dosyası (confusion matrix görselleri, `prediction_result.png`, ekran görüntüleri vb.).

Not: `archive/` içeriğini görmek için proje kökünde PowerShell ile `Get-ChildItem -Recurse archive` çalıştırabilirsiniz.

## Hızlı Çalıştırma

1) Gerekli paketleri kurun (`tensorflow`, `scikit-learn`, `scikit-image`, `flask`):

```powershell
cd 'C:\Users\HP\Desktop\FlowerProject'
pip install -r requirements.txt
```

2) Uygulamayı başlatın:

```powershell
python app.py
```

3) Tarayıcı önbelleği sorunlarını önlemek için sayfayı zorla yenileyin (Ctrl+F5).

## Notlar ve Öneriler

- Arşivleme güvenli yapılmıştır; dosyaları geri taşıma veya kalıcı silme isteğiniz olursa önce `archive/`'yi kontrol etmenizi öneririm.
- İsterseniz `.gitignore`'a `archive/` ekleyip arşiv dosyalarını git'e eklememeyi sağlayabilirim.

---
Bu döküman son yapılan değişikliklerin kısa özetini içerir. Daha fazla açıklama veya başka bir düzenleme isterseniz söyleyin.
    - Taşıma işlemi güvenli şekilde `archive/` altına yapıldı; eğer bir dosyayı geri taşımamı isterseniz söyleyin.
    - Eğer `archive/` içeriğini Git deposuna eklememek isterseniz `.gitignore` içine `archive/` satırını ekleyebilirim.
    - Projede daha temiz bir versiyonlama isterseniz, kullanılmayan modellerin kalıcı silinmesini yapabilirim (önce bir onay alacağım).

    ---
    Bu README, projede son dönemde yapılan transfer learning entegrasyonu, model iyileştirmesi (negatif örneklerle retraining), uygulama tarafı düzeltmeleri ve dosya arşivlemesini özetlemektedir.
    ```


