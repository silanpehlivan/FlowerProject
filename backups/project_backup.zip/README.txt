Archive manifest — moved files

This file lists the artifacts that were moved from the project root into `archive/` to keep the working tree small and the running app clean.

archive/models/
- best_svm_model.pkl
- best_svm_random_tuned.pkl
- best_svm_classweight.pkl
- scaler_classweight.pkl
- temel_svm_rbf_kernel_model.pkl
- tl_svm_model.pkl
- tl_scaler.pkl
- tl_bottleneck_features.npz
- features_combined.pkl
- features_color_only.pkl

archive/scripts/
- train_improved_tl_model.py
- transfer_mobilenet_svm.py
- svm_random_tune.py
- svm_optimization.py
- svm_classweight_trial.py
- model_training.py
- read_features.py
- quick_boost.py
- inspect_models.py
- compute_model_stats.py
- analyze_misclass.py
- predict_single_image.py

archive/images/
- numerous PNG outputs (confusion matrices, prediction_result.png, screenshots, etc.)

Notes:
- Files were moved (not deleted). If you need any removed file restored to the project root, reply with the filename and I'll move it back.
- Recommendation: keep `archive/` in `.gitignore` (already added) so these large artifacts are not accidentally committed.
